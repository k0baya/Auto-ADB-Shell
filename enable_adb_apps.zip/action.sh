#!/system/bin/sh

sh /data/adb/modules/AutoADBShell/service.sh